import React from 'react';
import './App.css';
import NoteApp from './components/NoteApp';

function App() {
  return (
    <div>
      <nav>
        <h1>My Notes</h1>
        <p>Write Anything You Want !</p>
      </nav>
     <div className="main">
     <NoteApp />
     </div>
    </div>
  );
}

export default App;
