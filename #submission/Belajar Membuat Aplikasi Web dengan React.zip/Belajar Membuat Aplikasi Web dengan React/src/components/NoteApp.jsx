import React from 'react';
import { NoteList } from './NoteList';
import { getNotesData } from '../NotesData';
import { NoteInsert }  from './NoteInsert';

class NoteApp extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      notes: getNotesData(),
    }
  
    this.onDeleteHandler = this.onDeleteHandler.bind(this);
    this.onAddNoteHandler = this.onAddNoteHandler.bind(this);
  }
  
  onDeleteHandler(id) {
    const notes = this.state.notes.filter(note => note.id !== id);
    
    this.setState({ notes });
  }

 
  onAddNoteHandler({ title, content }) {
    this.setState((prevState) => {
      const NoteCount = () => {
        return this.state.notes.length;
      }
      return {
        
        notes: [
          ...prevState.notes,
          {
            id:'00' + NoteCount(),
            title,
            content,
            createdAt:''+new Date(),
          }
        ]
      }
    });
  }

  render() {
    return (
      <div className='notes-app-wrapper'>
        <div className="notes-app-input">
          <h1>Tambah Note</h1>
          <hr />
          <br />
          <NoteInsert addNote={this.onAddNoteHandler} />
        </div>
        <div className="notes-app">
          <h1>Daftar Catatan</h1>
          <hr />
          <br />
          <div className="note-item-wrapper">
          {
              this.state.notes.length !== 0 ? (
                <NoteList notes={this.state.notes} onDelete={this.onDeleteHandler} />
              ) : (
                <p className='prompt'>Tidak ada catatan</p>
              )
              
            }
          </div>
        </div>
      </div>
      
    );
  }
}
export default NoteApp;