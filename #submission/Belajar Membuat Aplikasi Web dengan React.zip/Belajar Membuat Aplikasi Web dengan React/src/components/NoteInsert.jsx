import React from 'react';
import { BsPlusSquareFill } from "react-icons/bs";
 
export class NoteInsert extends React.Component {
 constructor(props) {
    super(props);
  
    // inisialisasi state
    this.state = {
      title: '',
      content: '',
    }
  
    this.onTitleChangeEventHandler = this.onTitleChangeEventHandler.bind(this);
    this.onContentChangeEventHandler = this.onContentChangeEventHandler.bind(this);
    this.onSubmitEventHandler = this.onSubmitEventHandler.bind(this);
  }
  
  onTitleChangeEventHandler(event) {
    this.setState(() => {
      return {
        title: event.target.value,
      }
    });
  }
  
  onContentChangeEventHandler(event) {
    this.setState(() => {
      return {
        content: event.target.value,
      }
    });
  }
  
  onSubmitEventHandler(event) {
    event.preventDefault();
    this.props.addNote(this.state);
  }

 render() {
   return (
     <form className='note-insert' onSubmit={this.onSubmitEventHandler}>
       <input className='input-title' type="text" placeholder="Title" value={this.state.title} onChange={this.onTitleChangeEventHandler} />
       <textarea className='input-content' type="text" placeholder="Content" value={this.state.content} onChange={this.onContentChangeEventHandler} />
       <button type="submit"><BsPlusSquareFill /> </button>
     </form>
   )
 }
}
