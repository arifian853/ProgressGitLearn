import React from 'react';
import { NoteStructures } from './NoteStructures';
import { DeleteButton } from './DeleteButton';

export const NoteItems = ({id, categories, createdAt, title, content, onDelete}) => {
  return (
    <div className='notes'>
        <NoteStructures id={id} categories={categories} createdAt={createdAt} title={title} content={content} />
        <br />
        <DeleteButton id={id} onDelete={onDelete} />
    </div>
  )
}
