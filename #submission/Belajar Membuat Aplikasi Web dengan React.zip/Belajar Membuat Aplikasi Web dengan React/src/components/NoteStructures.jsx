import React from 'react'

export const NoteStructures = ({id, createdAt, title, content}) => {
  return (
    <div className='note-structure'>
        <h1>{title}</h1>
        <hr />
        <span>Created at : {createdAt}</span>
        <hr />
        <div className="note-body">
            <p>{content}</p>
        </div>
        <hr />
        <span>Note ID : {id}</span>
    </div>
  )
}
