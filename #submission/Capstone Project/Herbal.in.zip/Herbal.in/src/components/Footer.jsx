import React from 'react'

export const Footer = () => {
  return (
    <footer>
        Copyright © 2022 Herbal.in - C22-05 
    </footer>
  )
}
