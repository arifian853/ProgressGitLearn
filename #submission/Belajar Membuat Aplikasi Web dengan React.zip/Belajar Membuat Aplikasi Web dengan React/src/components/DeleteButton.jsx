import React from "react";
import { FaTrash } from "react-icons/fa";

export const DeleteButton = ({ id, onDelete }) => {
  return (
    <button className="btn-delete" onClick={() => onDelete(id)}>
      <FaTrash />
    </button>
  );
};
